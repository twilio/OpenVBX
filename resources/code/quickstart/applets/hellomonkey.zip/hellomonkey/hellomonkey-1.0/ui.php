<div class="vbx-applet">
	<h2>This applet says "Hello Monkey" at this point during the call.</h2>
	<?php echo AppletUI::DropZone('primary'); ?>
</div>